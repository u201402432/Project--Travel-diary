package travel.mp.com.travel;

import android.app.Activity;
import android.os.Bundle;

public class setting extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting) ;

//      handler.sendEmptyMessageDelayed(0, 3000);
    }
}