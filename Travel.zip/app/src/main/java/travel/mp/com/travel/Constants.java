package travel.mp.com.travel;

/**
 * Created by admin on 2015-06-15.
 */
public class Constants {
    public static final String LOG_TAG = "Travel" ;
}