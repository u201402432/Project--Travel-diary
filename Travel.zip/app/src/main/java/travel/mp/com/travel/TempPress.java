package travel.mp.com.travel;

/**
 * Created by admin on 2015-06-17.
 */
import android.app.Activity;
import android.widget.Toast;

public class TempPress {
    private Toast toast;
    private Activity activity;


    public void on_temp() {
        //new prefActivity();
        showGuide();
        return;
    }

    public void showGuide() {

    }
}